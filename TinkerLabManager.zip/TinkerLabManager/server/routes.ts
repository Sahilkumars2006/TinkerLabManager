import { Router } from "express";
import jwt from "jsonwebtoken";
import { storage } from "./storage";
import { insertUserSchema, insertEquipmentSchema, insertReservationSchema } from "@shared/schema";
import { z } from "zod";

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Authentication middleware
const authenticateToken = async (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401);
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const user = await storage.getUser(decoded.userId);
    if (!user) {
      return res.sendStatus(403);
    }
    req.user = user;
    next();
  } catch (error) {
    return res.sendStatus(403);
  }
};

// Role-based authorization middleware
const requireRole = (roles: string[]) => {
  return (req: any, res: any, next: any) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.sendStatus(403);
    }
    next();
  };
};

// Mock email notification function
const sendEmailNotification = (recipient: string, subject: string, message: string) => {
  console.log(`\n=== EMAIL NOTIFICATION ===`);
  console.log(`TO: ${recipient}`);
  console.log(`SUBJECT: ${subject}`);
  console.log(`MESSAGE: ${message}`);
  console.log(`==========================\n`);
};

// Auth routes
router.post("/api/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required" });
    }

    const user = await storage.authenticateUser(username, password);
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '24h' });
    
    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        department: user.department,
      },
      token
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/api/auth/register", async (req, res) => {
  try {
    const userData = insertUserSchema.parse(req.body);
    
    // Check if user already exists
    const existingUser = await storage.getUserByUsername(userData.username);
    if (existingUser) {
      return res.status(400).json({ error: "Username already exists" });
    }

    const existingEmail = await storage.getUserByEmail(userData.email);
    if (existingEmail) {
      return res.status(400).json({ error: "Email already exists" });
    }

    const user = await storage.createUser(userData);
    
    res.status(201).json({
      id: user.id,
      username: user.username,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
    });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input data", details: error.errors });
    }
    console.error("Registration error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Equipment routes
router.get("/api/equipment", async (req, res) => {
  try {
    const { category, search } = req.query;
    
    let equipmentList;
    if (search) {
      equipmentList = await storage.searchEquipment(search as string);
    } else if (category) {
      equipmentList = await storage.getEquipmentByCategory(category as string);
    } else {
      equipmentList = await storage.getAllEquipment();
    }
    
    res.json(equipmentList);
  } catch (error) {
    console.error("Error fetching equipment:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/api/equipment/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const equipment = await storage.getEquipmentById(id);
    
    if (!equipment) {
      return res.status(404).json({ error: "Equipment not found" });
    }
    
    res.json(equipment);
  } catch (error) {
    console.error("Error fetching equipment:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/api/equipment", authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const equipmentData = insertEquipmentSchema.parse(req.body);
    const equipment = await storage.createEquipment(equipmentData);
    
    res.status(201).json(equipment);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input data", details: error.errors });
    }
    console.error("Error creating equipment:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Reservation routes
router.get("/api/reservations", authenticateToken, async (req, res) => {
  try {
    const { status, userId } = req.query;
    
    let reservationsList;
    if (status) {
      reservationsList = await storage.getReservationsByStatus(status as string);
    } else if (userId) {
      reservationsList = await storage.getReservationsByUser(parseInt(userId as string));
    } else {
      reservationsList = await storage.getAllReservations();
    }
    
    res.json(reservationsList);
  } catch (error) {
    console.error("Error fetching reservations:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/api/reservations/:id", authenticateToken, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const reservation = await storage.getReservationById(id);
    
    if (!reservation) {
      return res.status(404).json({ error: "Reservation not found" });
    }
    
    res.json(reservation);
  } catch (error) {
    console.error("Error fetching reservation:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/api/reservations", authenticateToken, async (req, res) => {
  try {
    const reservationData = insertReservationSchema.parse({
      ...req.body,
      userId: req.user.id,
    });
    
    // Calculate end date based on start date and duration
    const startDate = new Date(reservationData.startDate);
    const endDate = new Date(startDate.getTime() + reservationData.duration * 60 * 60 * 1000);
    
    const reservation = await storage.createReservation({
      ...reservationData,
      endDate,
    });
    
    // Send email notifications to authorizers
    const authorizers = ['tech.secretary@kit.edu', 'club.lead@kit.edu', 'faculty@kit.edu'];
    authorizers.forEach(email => {
      sendEmailNotification(
        email,
        'New Equipment Reservation Request',
        `A new reservation request has been submitted by ${req.user.fullName} for equipment ID ${reservationData.equipmentId}.`
      );
    });
    
    res.status(201).json(reservation);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input data", details: error.errors });
    }
    console.error("Error creating reservation:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/api/reservations/:id/approve", authenticateToken, requireRole(['tech_secretary', 'club_lead', 'faculty', 'phd_scholar', 'admin']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const reservation = await storage.updateReservationStatus(id, 'approved', req.user.id);
    
    // Get reservation details for email
    const reservationDetails = await storage.getReservationById(id);
    if (reservationDetails) {
      sendEmailNotification(
        reservationDetails.user.email,
        'Equipment Reservation Approved',
        `Your reservation for ${reservationDetails.equipment.name} has been approved by ${req.user.fullName}.`
      );
      
      // Update equipment status if approved
      await storage.updateEquipmentStatus(reservationDetails.equipmentId, 'reserved');
    }
    
    res.json(reservation);
  } catch (error) {
    console.error("Error approving reservation:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/api/reservations/:id/reject", authenticateToken, requireRole(['tech_secretary', 'club_lead', 'faculty', 'phd_scholar', 'admin']), async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { reason } = req.body;
    
    const reservation = await storage.updateReservationStatus(id, 'rejected', req.user.id, reason);
    
    // Get reservation details for email
    const reservationDetails = await storage.getReservationById(id);
    if (reservationDetails) {
      sendEmailNotification(
        reservationDetails.user.email,
        'Equipment Reservation Rejected',
        `Your reservation for ${reservationDetails.equipment.name} has been rejected. Reason: ${reason || 'No reason provided'}`
      );
    }
    
    res.json(reservation);
  } catch (error) {
    console.error("Error rejecting reservation:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/api/reservations/:id/checkin", authenticateToken, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const reservation = await storage.checkInEquipment(id);
    
    // Create usage log
    const reservationDetails = await storage.getReservationById(id);
    if (reservationDetails) {
      await storage.createUsageLog({
        reservationId: id,
        userId: reservationDetails.userId,
        equipmentId: reservationDetails.equipmentId,
        action: 'check_in',
        notes: 'Equipment checked in',
      });
      
      // Update equipment status
      await storage.updateEquipmentStatus(reservationDetails.equipmentId, 'in_use');
    }
    
    res.json(reservation);
  } catch (error) {
    console.error("Error checking in equipment:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/api/reservations/:id/checkout", authenticateToken, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const reservation = await storage.checkOutEquipment(id);
    
    // Create usage log
    const reservationDetails = await storage.getReservationById(id);
    if (reservationDetails) {
      await storage.createUsageLog({
        reservationId: id,
        userId: reservationDetails.userId,
        equipmentId: reservationDetails.equipmentId,
        action: 'check_out',
        notes: 'Equipment checked out',
      });
      
      // Update equipment status back to available
      await storage.updateEquipmentStatus(reservationDetails.equipmentId, 'available');
    }
    
    res.json(reservation);
  } catch (error) {
    console.error("Error checking out equipment:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Statistics routes
router.get("/api/stats/equipment", authenticateToken, async (req, res) => {
  try {
    const stats = await storage.getEquipmentUsageStats();
    res.json(stats);
  } catch (error) {
    console.error("Error fetching equipment stats:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/api/stats/departments", authenticateToken, async (req, res) => {
  try {
    const stats = await storage.getDepartmentUsageStats();
    res.json(stats);
  } catch (error) {
    console.error("Error fetching department stats:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/api/stats/overview", async (req, res) => {
  try {
    const stats = await storage.getReservationStats();
    res.json(stats);
  } catch (error) {
    console.error("Error fetching overview stats:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// User profile route
router.get("/api/user/profile", authenticateToken, async (req, res) => {
  try {
    const user = await storage.getUser(req.user.id);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      fullName: user.fullName,
      studentId: user.studentId,
      department: user.department,
      role: user.role,
    });
  } catch (error) {
    console.error("Error fetching user profile:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
