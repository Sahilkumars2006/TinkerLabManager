import { db } from "./db";
import { users, equipment } from "@shared/schema";
import bcrypt from "bcryptjs";

async function seedDatabase() {
  console.log("🌱 Seeding database...");

  try {
    // Create demo users
    const hashedPassword = await bcrypt.hash("password", 10);
    
    // Clear existing data
    await db.delete(equipment);
    await db.delete(users);

    const createdUsers = await db.insert(users).values([
      {
        username: "student",
        email: "student@kit.edu",
        password: hashedPassword,
        fullName: "John Student",
        studentId: "KIT2021001",
        department: "mechanical",
        role: "student",
      },
      {
        username: "tech",
        email: "tech@kit.edu", 
        password: hashedPassword,
        fullName: "Sarah Tech",
        studentId: "KIT2019001",
        department: "electrical",
        role: "tech_secretary",
      },
      {
        username: "faculty",
        email: "faculty@kit.edu",
        password: hashedPassword,
        fullName: "Dr. Robert Faculty",
        department: "mechanical",
        role: "faculty",
      },
      {
        username: "admin",
        email: "admin@kit.edu",
        password: hashedPassword,
        fullName: "Admin User",
        department: "computer",
        role: "admin",
      }
    ]).returning();

    console.log(`✅ Created ${createdUsers.length} users`);

    // Create equipment
    const equipmentData = await db.insert(equipment).values([
      {
        name: "Ultimaker S3 3D Printer",
        model: "S3",
        description: "Professional 3D printer with dual extrusion capability for complex prototypes",
        category: "3d-printing",
        location: "Lab Room A - Station 1",
        status: "available",
        specifications: "Build volume: 230 x 190 x 200 mm, Layer resolution: 0.25 mm",
        safetyRequirements: ["Safety training required", "Supervised use for first-time users"]
      },
      {
        name: "CNC Milling Machine",
        model: "Haas Mini Mill",
        description: "Precision CNC mill for metal and plastic machining",
        category: "mechanical", 
        location: "Workshop B - Bay 2",
        status: "available",
        specifications: "Spindle speed: 10,000 RPM, Work envelope: 16\" x 12\" x 10\"",
        safetyRequirements: ["CNC certification required", "Safety glasses mandatory"]
      },
      {
        name: "Oscilloscope",
        model: "Keysight DSOX3024T",
        description: "4-channel digital storage oscilloscope for circuit analysis",
        category: "electronics",
        location: "Electronics Lab - Bench 3",
        status: "available", 
        specifications: "Bandwidth: 200 MHz, Sample rate: 5 GSa/s, 4 analog channels",
        safetyRequirements: ["Basic electronics safety", "No food or drinks near equipment"]
      },
      {
        name: "Tensile Testing Machine",
        model: "Instron 5566",
        description: "Universal testing machine for material strength analysis",
        category: "testing",
        location: "Materials Lab - Station 1",
        status: "maintenance",
        specifications: "Load capacity: 10 kN, Crosshead speed: 0.001-500 mm/min",
        safetyRequirements: ["Materials testing certification", "Proper sample preparation required"]
      },
      {
        name: "Soldering Station",
        model: "Weller WES51",
        description: "Professional soldering station with temperature control",
        category: "electronics",
        location: "Electronics Lab - Bench 5",
        status: "available",
        specifications: "Power: 50W, Temperature range: 350-850°F",
        safetyRequirements: ["Soldering safety training", "Ventilation required"]
      },
      {
        name: "Laser Cutter",
        model: "Epilog Helix 24",
        description: "CO2 laser cutting and engraving system",
        category: "mechanical",
        location: "Fabrication Lab - Corner Station",
        status: "reserved",
        specifications: "Cutting area: 24\" x 18\", Laser power: 60W",
        safetyRequirements: ["Laser safety certification", "Material compatibility check required"]
      },
      {
        name: "Function Generator",
        model: "Agilent 33220A",
        description: "Arbitrary waveform generator for signal generation",
        category: "electronics",
        location: "Electronics Lab - Bench 1",
        status: "available",
        specifications: "Frequency range: 1 µHz to 20 MHz, Arbitrary waveforms",
        safetyRequirements: ["Basic electronics knowledge", "Proper grounding required"]
      },
      {
        name: "Formlabs Form 3 SLA Printer",
        model: "Form 3",
        description: "Stereolithography 3D printer for high-resolution parts",
        category: "3d-printing",
        location: "Lab Room A - Station 3",
        status: "available",
        specifications: "Build volume: 145 × 145 × 185 mm, Layer thickness: 25-300 microns",
        safetyRequirements: ["Resin handling safety", "Proper ventilation required", "Gloves mandatory"]
      }
    ]).returning();

    console.log(`✅ Created ${equipmentData.length} equipment items`);

    console.log("🎉 Database seeded successfully!");
    
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Run if called directly
if (import.meta.main) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export { seedDatabase };