import { eq, and, desc, asc, count, sql, gte, lte } from "drizzle-orm";
import { db } from "./db";
import {
  users,
  equipment,
  reservations,
  usageLogs,
  safetyTraining,
  type User,
  type InsertUser,
  type Equipment,
  type InsertEquipment,
  type Reservation,
  type InsertReservation,
  type ReservationWithDetails,
  type UsageLog,
  type InsertUsageLog,
  type SafetyTraining,
  type InsertSafetyTraining,
} from "@shared/schema";
import bcrypt from "bcryptjs";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  authenticateUser(username: string, password: string): Promise<User | null>;
  
  // Equipment methods
  getAllEquipment(): Promise<Equipment[]>;
  getEquipmentById(id: number): Promise<Equipment | undefined>;
  getEquipmentByCategory(category: string): Promise<Equipment[]>;
  createEquipment(insertEquipment: InsertEquipment): Promise<Equipment>;
  updateEquipmentStatus(id: number, status: string): Promise<Equipment>;
  searchEquipment(query: string): Promise<Equipment[]>;
  
  // Reservation methods
  getAllReservations(): Promise<ReservationWithDetails[]>;
  getReservationById(id: number): Promise<ReservationWithDetails | undefined>;
  getReservationsByUser(userId: number): Promise<ReservationWithDetails[]>;
  getReservationsByStatus(status: string): Promise<ReservationWithDetails[]>;
  createReservation(insertReservation: InsertReservation): Promise<Reservation>;
  updateReservationStatus(id: number, status: string, approvedBy?: number, rejectionReason?: string): Promise<Reservation>;
  checkInEquipment(reservationId: number): Promise<Reservation>;
  checkOutEquipment(reservationId: number): Promise<Reservation>;
  
  // Usage log methods
  createUsageLog(insertUsageLog: InsertUsageLog): Promise<UsageLog>;
  getUsageLogsByEquipment(equipmentId: number): Promise<UsageLog[]>;
  
  // Safety training methods
  getUserSafetyTraining(userId: number): Promise<SafetyTraining[]>;
  createSafetyTraining(insertSafetyTraining: InsertSafetyTraining): Promise<SafetyTraining>;
  
  // Analytics methods
  getEquipmentUsageStats(): Promise<any>;
  getDepartmentUsageStats(): Promise<any>;
  getReservationStats(): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, password: hashedPassword })
      .returning();
    return user;
  }

  async authenticateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  }

  async getAllEquipment(): Promise<Equipment[]> {
    return await db.select().from(equipment).orderBy(asc(equipment.name));
  }

  async getEquipmentById(id: number): Promise<Equipment | undefined> {
    const [item] = await db.select().from(equipment).where(eq(equipment.id, id));
    return item || undefined;
  }

  async getEquipmentByCategory(category: string): Promise<Equipment[]> {
    return await db.select().from(equipment).where(eq(equipment.category, category as any));
  }

  async createEquipment(insertEquipment: InsertEquipment): Promise<Equipment> {
    const [item] = await db
      .insert(equipment)
      .values(insertEquipment)
      .returning();
    return item;
  }

  async updateEquipmentStatus(id: number, status: string): Promise<Equipment> {
    const [item] = await db
      .update(equipment)
      .set({ status: status as any, updatedAt: new Date() })
      .where(eq(equipment.id, id))
      .returning();
    return item;
  }

  async searchEquipment(query: string): Promise<Equipment[]> {
    return await db
      .select()
      .from(equipment)
      .where(
        sql`${equipment.name} ILIKE ${'%' + query + '%'} OR ${equipment.description} ILIKE ${'%' + query + '%'}`
      );
  }

  async getAllReservations(): Promise<ReservationWithDetails[]> {
    return await db
      .select({
        id: reservations.id,
        userId: reservations.userId,
        equipmentId: reservations.equipmentId,
        startDate: reservations.startDate,
        endDate: reservations.endDate,
        duration: reservations.duration,
        projectDescription: reservations.projectDescription,
        priority: reservations.priority,
        status: reservations.status,
        approvedBy: reservations.approvedBy,
        approvedAt: reservations.approvedAt,
        rejectionReason: reservations.rejectionReason,
        checkedInAt: reservations.checkedInAt,
        checkedOutAt: reservations.checkedOutAt,
        createdAt: reservations.createdAt,
        updatedAt: reservations.updatedAt,
        user: users,
        equipment: equipment,
        approver: sql<User | null>`
          CASE WHEN ${reservations.approvedBy} IS NOT NULL THEN
            ${sql`(SELECT row_to_json(approver.*) FROM ${users} approver WHERE approver.id = ${reservations.approvedBy})`}
          ELSE NULL END
        `,
      })
      .from(reservations)
      .leftJoin(users, eq(reservations.userId, users.id))
      .leftJoin(equipment, eq(reservations.equipmentId, equipment.id))
      .orderBy(desc(reservations.createdAt)) as ReservationWithDetails[];
  }

  async getReservationById(id: number): Promise<ReservationWithDetails | undefined> {
    const [reservation] = await db
      .select({
        id: reservations.id,
        userId: reservations.userId,
        equipmentId: reservations.equipmentId,
        startDate: reservations.startDate,
        endDate: reservations.endDate,
        duration: reservations.duration,
        projectDescription: reservations.projectDescription,
        priority: reservations.priority,
        status: reservations.status,
        approvedBy: reservations.approvedBy,
        approvedAt: reservations.approvedAt,
        rejectionReason: reservations.rejectionReason,
        checkedInAt: reservations.checkedInAt,
        checkedOutAt: reservations.checkedOutAt,
        createdAt: reservations.createdAt,
        updatedAt: reservations.updatedAt,
        user: users,
        equipment: equipment,
        approver: sql<User | null>`
          CASE WHEN ${reservations.approvedBy} IS NOT NULL THEN
            ${sql`(SELECT row_to_json(approver.*) FROM ${users} approver WHERE approver.id = ${reservations.approvedBy})`}
          ELSE NULL END
        `,
      })
      .from(reservations)
      .leftJoin(users, eq(reservations.userId, users.id))
      .leftJoin(equipment, eq(reservations.equipmentId, equipment.id))
      .where(eq(reservations.id, id)) as ReservationWithDetails[];
    
    return reservation || undefined;
  }

  async getReservationsByUser(userId: number): Promise<ReservationWithDetails[]> {
    return await db
      .select({
        id: reservations.id,
        userId: reservations.userId,
        equipmentId: reservations.equipmentId,
        startDate: reservations.startDate,
        endDate: reservations.endDate,
        duration: reservations.duration,
        projectDescription: reservations.projectDescription,
        priority: reservations.priority,
        status: reservations.status,
        approvedBy: reservations.approvedBy,
        approvedAt: reservations.approvedAt,
        rejectionReason: reservations.rejectionReason,
        checkedInAt: reservations.checkedInAt,
        checkedOutAt: reservations.checkedOutAt,
        createdAt: reservations.createdAt,
        updatedAt: reservations.updatedAt,
        user: users,
        equipment: equipment,
        approver: sql<User | null>`
          CASE WHEN ${reservations.approvedBy} IS NOT NULL THEN
            ${sql`(SELECT row_to_json(approver.*) FROM ${users} approver WHERE approver.id = ${reservations.approvedBy})`}
          ELSE NULL END
        `,
      })
      .from(reservations)
      .leftJoin(users, eq(reservations.userId, users.id))
      .leftJoin(equipment, eq(reservations.equipmentId, equipment.id))
      .where(eq(reservations.userId, userId))
      .orderBy(desc(reservations.createdAt)) as ReservationWithDetails[];
  }

  async getReservationsByStatus(status: string): Promise<ReservationWithDetails[]> {
    return await db
      .select({
        id: reservations.id,
        userId: reservations.userId,
        equipmentId: reservations.equipmentId,
        startDate: reservations.startDate,
        endDate: reservations.endDate,
        duration: reservations.duration,
        projectDescription: reservations.projectDescription,
        priority: reservations.priority,
        status: reservations.status,
        approvedBy: reservations.approvedBy,
        approvedAt: reservations.approvedAt,
        rejectionReason: reservations.rejectionReason,
        checkedInAt: reservations.checkedInAt,
        checkedOutAt: reservations.checkedOutAt,
        createdAt: reservations.createdAt,
        updatedAt: reservations.updatedAt,
        user: users,
        equipment: equipment,
        approver: sql<User | null>`
          CASE WHEN ${reservations.approvedBy} IS NOT NULL THEN
            ${sql`(SELECT row_to_json(approver.*) FROM ${users} approver WHERE approver.id = ${reservations.approvedBy})`}
          ELSE NULL END
        `,
      })
      .from(reservations)
      .leftJoin(users, eq(reservations.userId, users.id))
      .leftJoin(equipment, eq(reservations.equipmentId, equipment.id))
      .where(eq(reservations.status, status as any))
      .orderBy(desc(reservations.createdAt)) as ReservationWithDetails[];
  }

  async createReservation(insertReservation: InsertReservation): Promise<Reservation> {
    const [reservation] = await db
      .insert(reservations)
      .values(insertReservation)
      .returning();
    return reservation;
  }

  async updateReservationStatus(
    id: number,
    status: string,
    approvedBy?: number,
    rejectionReason?: string
  ): Promise<Reservation> {
    const updateData: any = {
      status: status as any,
      updatedAt: new Date(),
    };

    if (approvedBy) {
      updateData.approvedBy = approvedBy;
      updateData.approvedAt = new Date();
    }

    if (rejectionReason) {
      updateData.rejectionReason = rejectionReason;
    }

    const [reservation] = await db
      .update(reservations)
      .set(updateData)
      .where(eq(reservations.id, id))
      .returning();
    return reservation;
  }

  async checkInEquipment(reservationId: number): Promise<Reservation> {
    const [reservation] = await db
      .update(reservations)
      .set({
        checkedInAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(reservations.id, reservationId))
      .returning();
    return reservation;
  }

  async checkOutEquipment(reservationId: number): Promise<Reservation> {
    const [reservation] = await db
      .update(reservations)
      .set({
        checkedOutAt: new Date(),
        status: 'completed',
        updatedAt: new Date(),
      })
      .where(eq(reservations.id, reservationId))
      .returning();
    return reservation;
  }

  async createUsageLog(insertUsageLog: InsertUsageLog): Promise<UsageLog> {
    const [log] = await db
      .insert(usageLogs)
      .values(insertUsageLog)
      .returning();
    return log;
  }

  async getUsageLogsByEquipment(equipmentId: number): Promise<UsageLog[]> {
    return await db
      .select()
      .from(usageLogs)
      .where(eq(usageLogs.equipmentId, equipmentId))
      .orderBy(desc(usageLogs.timestamp));
  }

  async getUserSafetyTraining(userId: number): Promise<SafetyTraining[]> {
    return await db
      .select()
      .from(safetyTraining)
      .where(eq(safetyTraining.userId, userId))
      .orderBy(desc(safetyTraining.completedAt));
  }

  async createSafetyTraining(insertSafetyTraining: InsertSafetyTraining): Promise<SafetyTraining> {
    const [training] = await db
      .insert(safetyTraining)
      .values(insertSafetyTraining)
      .returning();
    return training;
  }

  async getEquipmentUsageStats(): Promise<any> {
    const stats = await db
      .select({
        category: equipment.category,
        total: count(equipment.id),
        available: sql<number>`COUNT(CASE WHEN ${equipment.status} = 'available' THEN 1 END)`,
        inUse: sql<number>`COUNT(CASE WHEN ${equipment.status} = 'in_use' THEN 1 END)`,
        maintenance: sql<number>`COUNT(CASE WHEN ${equipment.status} = 'maintenance' THEN 1 END)`,
      })
      .from(equipment)
      .groupBy(equipment.category);
    
    return stats;
  }

  async getDepartmentUsageStats(): Promise<any> {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const stats = await db
      .select({
        department: users.department,
        totalReservations: count(reservations.id),
        totalHours: sql<number>`SUM(${reservations.duration})`,
      })
      .from(reservations)
      .leftJoin(users, eq(reservations.userId, users.id))
      .where(gte(reservations.createdAt, thirtyDaysAgo))
      .groupBy(users.department);

    return stats;
  }

  async getReservationStats(): Promise<any> {
    const today = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const [totalStats] = await db
      .select({
        totalEquipment: sql<number>`(SELECT COUNT(*) FROM ${equipment})`,
        availableEquipment: sql<number>`(SELECT COUNT(*) FROM ${equipment} WHERE status = 'available')`,
        equipmentInUse: sql<number>`(SELECT COUNT(*) FROM ${equipment} WHERE status = 'in_use')`,
        maintenanceCount: sql<number>`(SELECT COUNT(*) FROM ${equipment} WHERE status = 'maintenance')`,
        activeReservations: sql<number>`(SELECT COUNT(*) FROM ${reservations} WHERE status = 'approved')`,
        pendingReservations: sql<number>`(SELECT COUNT(*) FROM ${reservations} WHERE status = 'pending')`,
      })
      .from(sql`(SELECT 1) as dummy`);

    return totalStats;
  }
}

export const storage = new DatabaseStorage();
