import { useState } from "react";
import { Check, X, Eye, Clock } from "lucide-react";
import { Button } from "./button";
import { Badge } from "./badge";
import { Avatar, AvatarFallback } from "./avatar";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./tabs";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./dialog";
import { Textarea } from "./textarea";
import type { ReservationWithDetails } from "@shared/schema";

export function DashboardTable() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [rejectionReason, setRejectionReason] = useState('');
  const [selectedReservationId, setSelectedReservationId] = useState<number | null>(null);

  const { data: allReservations = [], isLoading } = useQuery<ReservationWithDetails[]>({
    queryKey: ['/api/reservations'],
  });

  const pendingReservations = allReservations.filter(r => r.status === 'pending');
  const approvedReservations = allReservations.filter(r => r.status === 'approved');
  const rejectedReservations = allReservations.filter(r => r.status === 'rejected');

  const approveMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/reservations/${id}/approve`, {
        method: 'PATCH',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/equipment'] });
      toast({
        title: "Reservation Approved",
        description: "The reservation has been approved successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve reservation",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: number; reason: string }) => {
      return apiRequest(`/api/reservations/${id}/reject`, {
        method: 'PATCH',
        body: JSON.stringify({ reason }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
      setRejectionReason('');
      setSelectedReservationId(null);
      toast({
        title: "Reservation Rejected",
        description: "The reservation has been rejected.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject reservation",
        variant: "destructive",
      });
    },
  });

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Urgent</Badge>;
      case 'high':
        return <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-100">High</Badge>;
      default:
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Normal</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  const handleReject = (reservationId: number) => {
    if (!rejectionReason.trim()) {
      toast({
        title: "Rejection Reason Required",
        description: "Please provide a reason for rejection.",
        variant: "destructive",
      });
      return;
    }
    rejectMutation.mutate({ id: reservationId, reason: rejectionReason });
  };

  const ReservationRow = ({ reservation }: { reservation: ReservationWithDetails }) => (
    <TableRow className="hover:bg-gray-50">
      <TableCell>
        <div className="flex items-center">
          <Avatar className="h-10 w-10">
            <AvatarFallback className="bg-[hsl(var(--primary))] text-white text-sm font-medium">
              {getInitials(reservation.user.fullName)}
            </AvatarFallback>
          </Avatar>
          <div className="ml-4">
            <div className="text-sm font-medium text-gray-900">{reservation.user.fullName}</div>
            <div className="text-sm text-gray-500">
              {reservation.user.studentId} • {reservation.user.department && reservation.user.department.replace('_', ' ')}
            </div>
            <div className="text-xs text-gray-400">{reservation.user.email}</div>
          </div>
        </div>
      </TableCell>
      <TableCell>
        <div className="text-sm font-medium text-gray-900">{reservation.equipment.name}</div>
        <div className="text-sm text-gray-500 capitalize">{reservation.equipment.category.replace('-', ' ')}</div>
        <div className="text-xs text-gray-400">{reservation.equipment.location}</div>
      </TableCell>
      <TableCell>
        <div className="text-sm font-medium text-gray-900">{formatDate(reservation.startDate)}</div>
        <div className="text-sm text-gray-500">
          {formatTime(reservation.startDate)} - {formatTime(reservation.endDate)}
        </div>
        <div className="text-xs text-gray-400">{reservation.duration} hours duration</div>
      </TableCell>
      <TableCell>{getPriorityBadge(reservation.priority)}</TableCell>
      <TableCell>
        <div className="flex space-x-2">
          {reservation.status === 'pending' && (
            <>
              <Button
                size="sm"
                className="bg-[hsl(var(--secondary))] hover:bg-[hsl(var(--secondary))]/90"
                onClick={() => approveMutation.mutate(reservation.id)}
                disabled={approveMutation.isPending}
              >
                <Check className="w-4 h-4 mr-1" />
                Approve
              </Button>
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => setSelectedReservationId(reservation.id)}
                  >
                    <X className="w-4 h-4 mr-1" />
                    Reject
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Reject Reservation</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p className="text-sm text-gray-600">
                      Please provide a reason for rejecting this reservation request.
                    </p>
                    <Textarea
                      placeholder="Enter rejection reason..."
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      rows={3}
                    />
                    <div className="flex justify-end space-x-2">
                      <Button variant="outline" onClick={() => setRejectionReason('')}>
                        Cancel
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={() => handleReject(reservation.id)}
                        disabled={rejectMutation.isPending}
                      >
                        Reject Request
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </>
          )}
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline">
                <Eye className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Reservation Details</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-gray-900">Student Information</h4>
                    <p className="text-sm text-gray-600">{reservation.user.fullName}</p>
                    <p className="text-sm text-gray-600">{reservation.user.email}</p>
                    <p className="text-sm text-gray-600">{reservation.user.studentId}</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Equipment</h4>
                    <p className="text-sm text-gray-600">{reservation.equipment.name}</p>
                    <p className="text-sm text-gray-600">{reservation.equipment.location}</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">Project Description</h4>
                  <p className="text-sm text-gray-600">{reservation.projectDescription}</p>
                </div>
                {reservation.rejectionReason && (
                  <div>
                    <h4 className="font-medium text-gray-900">Rejection Reason</h4>
                    <p className="text-sm text-gray-600">{reservation.rejectionReason}</p>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </TableCell>
    </TableRow>
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Clock className="w-8 h-8 animate-spin mx-auto mb-2" />
          <p>Loading reservations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-2xl font-bold text-gray-900">Authorizer Dashboard</h3>
          <p className="text-gray-600">Review and manage equipment reservation requests</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="bg-[hsl(var(--surface-variant))] rounded-lg px-3 py-2">
            <span className="text-sm text-gray-600">Pending Requests:</span>
            <span className="font-bold text-[hsl(var(--accent))] ml-1">{pendingReservations.length}</span>
          </div>
        </div>
      </div>

      <Tabs defaultValue="pending" className="w-full">
        <TabsList>
          <TabsTrigger value="pending">
            Pending Approval ({pendingReservations.length})
          </TabsTrigger>
          <TabsTrigger value="approved">
            Approved ({approvedReservations.length})
          </TabsTrigger>
          <TabsTrigger value="rejected">
            Rejected ({rejectedReservations.length})
          </TabsTrigger>
          <TabsTrigger value="all">
            All Requests ({allReservations.length})
          </TabsTrigger>
        </TabsList>

        <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-material mt-4">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-[hsl(var(--surface-variant))]">
                  <TableHead>Request Details</TableHead>
                  <TableHead>Equipment</TableHead>
                  <TableHead>Schedule</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TabsContent value="pending" className="mt-0">
                  {pendingReservations.map((reservation) => (
                    <ReservationRow key={reservation.id} reservation={reservation} />
                  ))}
                  {pendingReservations.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8">
                        <div className="text-gray-500">
                          <Clock className="w-8 h-8 mx-auto mb-2" />
                          <p>No pending reservations</p>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TabsContent>
                
                <TabsContent value="approved" className="mt-0">
                  {approvedReservations.map((reservation) => (
                    <ReservationRow key={reservation.id} reservation={reservation} />
                  ))}
                </TabsContent>
                
                <TabsContent value="rejected" className="mt-0">
                  {rejectedReservations.map((reservation) => (
                    <ReservationRow key={reservation.id} reservation={reservation} />
                  ))}
                </TabsContent>
                
                <TabsContent value="all" className="mt-0">
                  {allReservations.map((reservation) => (
                    <ReservationRow key={reservation.id} reservation={reservation} />
                  ))}
                </TabsContent>
              </TableBody>
            </Table>
          </div>
        </div>
      </Tabs>
    </div>
  );
}
