import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "./button";
import { Input } from "./input";
import { Textarea } from "./textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./select";
import { Checkbox } from "./checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "./card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "./form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Equipment } from "@shared/schema";

const reservationSchema = z.object({
  equipmentId: z.coerce.number(),
  startDate: z.string().min(1, "Start date is required"),
  startTime: z.string().min(1, "Start time is required"),
  duration: z.coerce.number().min(1, "Duration is required"),
  projectDescription: z.string().min(10, "Project description must be at least 10 characters"),
  priority: z.enum(['normal', 'high', 'urgent']),
  safetyAgreement: z.boolean().refine(val => val === true, "You must accept the safety agreement"),
});

type ReservationFormData = z.infer<typeof reservationSchema>;

interface ReservationFormProps {
  selectedEquipmentId?: number;
  onSuccess?: () => void;
}

export function ReservationForm({ selectedEquipmentId, onSuccess }: ReservationFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: equipment = [] } = useQuery<Equipment[]>({
    queryKey: ['/api/equipment'],
  });

  const { data: user } = useQuery<any>({
    queryKey: ['/api/user/profile'],
  });

  const form = useForm<ReservationFormData>({
    resolver: zodResolver(reservationSchema),
    defaultValues: {
      equipmentId: selectedEquipmentId || 0,
      startDate: '',
      startTime: '',
      duration: 2,
      projectDescription: '',
      priority: 'normal',
      safetyAgreement: false,
    },
  });

  const createReservationMutation = useMutation({
    mutationFn: async (data: ReservationFormData) => {
      // Combine date and time into a proper datetime
      const startDateTime = new Date(`${data.startDate}T${data.startTime}`);
      
      return apiRequest('/api/reservations', {
        method: 'POST',
        body: JSON.stringify({
          equipmentId: data.equipmentId,
          startDate: startDateTime.toISOString(),
          duration: data.duration,
          projectDescription: data.projectDescription,
          priority: data.priority,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/equipment'] });
      toast({
        title: "Reservation Submitted",
        description: "Your reservation request has been submitted for approval.",
      });
      form.reset();
      onSuccess?.();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit reservation",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ReservationFormData) => {
    createReservationMutation.mutate(data);
  };

  const availableEquipment = equipment.filter(eq => eq.status === 'available');

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">Make a Reservation</CardTitle>
        <p className="text-center text-gray-600">
          Fill out the form below to request equipment access. Your request will be sent for approval.
        </p>
      </CardHeader>
      
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="equipmentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Equipment *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value?.toString()}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Equipment" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {availableEquipment.map((eq) => (
                          <SelectItem key={eq.id} value={eq.id.toString()}>
                            {eq.name} - {eq.category.replace('-', ' ')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority Level</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="high">High Priority</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Date *</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="startTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Time *</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="duration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Duration (hours) *</FormLabel>
                    <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select Duration" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="1">1 hour</SelectItem>
                        <SelectItem value="2">2 hours</SelectItem>
                        <SelectItem value="3">3 hours</SelectItem>
                        <SelectItem value="4">4 hours</SelectItem>
                        <SelectItem value="6">6 hours</SelectItem>
                        <SelectItem value="8">8 hours</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="projectDescription"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Project Description *</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe your project and how you plan to use the equipment..."
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-[hsl(var(--surface-variant))] rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-3">Safety Training Status</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Checkbox id="safety-general" checked readOnly />
                  <label htmlFor="safety-general" className="text-sm text-gray-700">
                    General Lab Safety Training
                  </label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox id="safety-equipment" checked readOnly />
                  <label htmlFor="safety-equipment" className="text-sm text-gray-700">
                    Equipment-Specific Safety Training
                  </label>
                </div>
                <div className="flex items-center space-x-3">
                  <Checkbox id="safety-emergency" readOnly />
                  <label htmlFor="safety-emergency" className="text-sm text-gray-700">
                    Emergency Procedures (Optional)
                  </label>
                </div>
              </div>
            </div>

            <FormField
              control={form.control}
              name="safetyAgreement"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-sm font-normal">
                      I agree to the lab usage terms and conditions and understand that I am responsible 
                      for any damage or misuse of equipment during my reservation period. *
                    </FormLabel>
                    <FormMessage />
                  </div>
                </FormItem>
              )}
            />

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                type="submit"
                className="flex-1"
                disabled={createReservationMutation.isPending}
              >
                {createReservationMutation.isPending ? 'Submitting...' : 'Submit Reservation Request'}
              </Button>
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => form.reset()}
              >
                Clear Form
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
