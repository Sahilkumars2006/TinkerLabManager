import { Link, useLocation } from "wouter";
import { Bell, Menu, Settings, User, LogOut } from "lucide-react";
import { Button } from "./button";
import { Avatar, AvatarFallback } from "./avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./dropdown-menu";
import { useQuery, useQueryClient } from "@tanstack/react-query";

interface User {
  id: number;
  fullName: string;
  role: string;
  email: string;
}

export function Navigation() {
  const [location] = useLocation();
  const queryClient = useQueryClient();

  const { data: user } = useQuery<User>({
    queryKey: ['/api/user/profile'],
    enabled: !!localStorage.getItem('token'),
  });

  const { data: stats } = useQuery<any>({
    queryKey: ['/api/stats/overview'],
  });

  const handleLogout = () => {
    localStorage.removeItem('token');
    queryClient.clear();
    window.location.href = '/login';
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (!user) {
    return null;
  }

  return (
    <nav className="bg-white shadow-material-lg fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <div className="flex items-center space-x-3 cursor-pointer">
                <div className="bg-[hsl(var(--primary))] text-white p-2 rounded-lg">
                  <div className="w-6 h-6 flex items-center justify-center">
                    🔧
                  </div>
                </div>
                <div>
                  <h1 className="text-xl font-medium text-gray-900">KIT Tinker Lab</h1>
                  <p className="text-sm text-gray-600">Management System</p>
                </div>
              </div>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/equipment">
              <Button
                variant={location === '/equipment' ? 'default' : 'ghost'}
                className="font-medium"
              >
                Equipment
              </Button>
            </Link>
            <Link href="/reservations">
              <Button
                variant={location === '/reservations' ? 'default' : 'ghost'}
                className="font-medium"
              >
                Reservations
              </Button>
            </Link>
            <Link href="/inventory">
              <Button
                variant={location === '/inventory' ? 'default' : 'ghost'}
                className="font-medium"
              >
                Inventory
              </Button>
            </Link>
            <Link href="/reports">
              <Button
                variant={location === '/reports' ? 'default' : 'ghost'}
                className="font-medium"
              >
                Reports
              </Button>
            </Link>
            {(user.role === 'tech_secretary' || user.role === 'club_lead' || user.role === 'faculty' || user.role === 'phd_scholar' || user.role === 'admin') && (
              <Link href="/dashboard">
                <Button
                  variant={location === '/dashboard' ? 'default' : 'ghost'}
                  className="font-medium"
                >
                  Dashboard
                </Button>
              </Link>
            )}
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 bg-[hsl(var(--accent))] text-white text-xs rounded-full px-1 min-w-[16px] h-4 flex items-center justify-center">
                3
              </span>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-[hsl(var(--primary))] text-white text-sm font-medium">
                      {getInitials(user.fullName)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden sm:block text-left">
                    <p className="text-sm font-medium text-gray-900">{user.fullName}</p>
                    <p className="text-xs text-gray-600 capitalize">{user.role.replace('_', ' ')}</p>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}
