import { Clock, MapPin, Settings, CheckCircle, AlertTriangle, Wrench } from "lucide-react";
import { Button } from "./button";
import { Badge } from "./badge";
import { Card, CardContent, CardFooter } from "./card";
import type { Equipment } from "@shared/schema";

interface EquipmentCardProps {
  equipment: Equipment;
  onReserve: (equipmentId: number) => void;
  onViewDetails: (equipmentId: number) => void;
}

export function EquipmentCard({ equipment, onReserve, onViewDetails }: EquipmentCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'available':
        return (
          <Badge className="bg-[hsl(var(--secondary))] text-white hover:bg-[hsl(var(--secondary))]">
            <CheckCircle className="w-3 h-3 mr-1" />
            Available
          </Badge>
        );
      case 'reserved':
        return (
          <Badge className="bg-[hsl(var(--accent))] text-white hover:bg-[hsl(var(--accent))]">
            <Clock className="w-3 h-3 mr-1" />
            Reserved
          </Badge>
        );
      case 'in_use':
        return (
          <Badge className="bg-blue-500 text-white hover:bg-blue-500">
            <Settings className="w-3 h-3 mr-1" />
            In Use
          </Badge>
        );
      case 'maintenance':
        return (
          <Badge className="bg-[hsl(var(--error))] text-white hover:bg-[hsl(var(--error))]">
            <Wrench className="w-3 h-3 mr-1" />
            Maintenance
          </Badge>
        );
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getNextAvailable = (status: string) => {
    if (status === 'available') return 'Now';
    if (status === 'reserved') return 'Dec 5, 2:00 PM';
    if (status === 'maintenance') return 'Dec 8, 9:00 AM';
    return 'Unknown';
  };

  const isReservable = equipment.status === 'available';

  return (
    <Card className="bg-white border border-gray-200 hover:shadow-material-lg transition-shadow">
      <div className="w-full h-48 bg-gray-100 rounded-t-lg flex items-center justify-center">
        <div className="text-gray-400 text-center">
          <Settings className="w-12 h-12 mx-auto mb-2" />
          <p className="text-sm">Equipment Image</p>
        </div>
      </div>
      
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-3">
          <h4 className="text-lg font-medium text-gray-900">{equipment.name}</h4>
          {getStatusBadge(equipment.status)}
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {equipment.description || 'No description available'}
        </p>
        
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600 flex items-center">
              <MapPin className="w-3 h-3 mr-1" />
              Location:
            </span>
            <span className="font-medium">{equipment.location}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Category:</span>
            <span className="font-medium capitalize">{equipment.category.replace('-', ' ')}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600 flex items-center">
              <Clock className="w-3 h-3 mr-1" />
              Next Available:
            </span>
            <span className={`font-medium ${equipment.status === 'available' ? 'text-[hsl(var(--secondary))]' : 'text-[hsl(var(--accent))]'}`}>
              {getNextAvailable(equipment.status)}
            </span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-6 pt-0">
        <div className="flex gap-3 w-full">
          <Button
            className="flex-1"
            onClick={() => onReserve(equipment.id)}
            disabled={!isReservable}
            variant={isReservable ? "default" : "secondary"}
          >
            {isReservable ? 'Reserve' : equipment.status === 'maintenance' ? 'Maintenance' : 'Reserved'}
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => onViewDetails(equipment.id)}
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
