import { Navigation } from "@/components/ui/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Settings, Calendar, BarChart3, BookOpen } from "lucide-react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";

export default function HomePage() {
  const { data: stats } = useQuery<any>({
    queryKey: ['/api/stats/overview'],
  });

  const { data: user } = useQuery<any>({
    queryKey: ['/api/user/profile'],
  });

  return (
    <div className="min-h-screen bg-[hsl(var(--surface))]">
      <Navigation />
      
      <div className="pt-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-[hsl(var(--primary))] to-[hsl(var(--primary-dark))] text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold mb-6">Welcome to KIT Tinker Lab</h2>
                <p className="text-xl text-blue-100 mb-8">
                  Streamlined equipment management, reservations, and inventory tracking for our state-of-the-art prototyping facility.
                </p>
                
                <div className="grid grid-cols-2 gap-6 mb-8">
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                    <div className="text-2xl font-bold">{stats?.totalEquipment || 24}</div>
                    <div className="text-blue-100">Equipment Items</div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                    <div className="text-2xl font-bold">{stats?.activeReservations || 12}</div>
                    <div className="text-blue-100">Active Reservations</div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-4">
                  <Link href="/equipment">
                    <Button className="bg-white text-[hsl(var(--primary))] hover:bg-gray-100">
                      Browse Equipment
                    </Button>
                  </Link>
                  <Link href="/reservations">
                    <Button variant="outline" className="border-white text-white hover:bg-white/10">
                      Make Reservation
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="hidden md:block">
                <div className="w-full h-96 bg-white/10 rounded-xl flex items-center justify-center">
                  <div className="text-center text-white/70">
                    <div className="text-6xl mb-4">🔧</div>
                    <p>Modern Engineering Lab</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Quick Actions</h3>
              <p className="text-gray-600">Get started with these common tasks</p>
            </div>
            
            <div className="grid md:grid-cols-4 gap-6">
              <Link href="/equipment">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="bg-[hsl(var(--primary))] text-white p-3 rounded-lg w-12 h-12 flex items-center justify-center mx-auto mb-4">
                        <Settings className="w-6 h-6" />
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">Browse Equipment</h4>
                      <p className="text-sm text-gray-600">View available lab equipment</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
              
              <Link href="/reservations">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="bg-[hsl(var(--secondary))] text-white p-3 rounded-lg w-12 h-12 flex items-center justify-center mx-auto mb-4">
                        <Calendar className="w-6 h-6" />
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">Make Reservation</h4>
                      <p className="text-sm text-gray-600">Request equipment access</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
              
              <Link href="/inventory">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="bg-[hsl(var(--accent))] text-white p-3 rounded-lg w-12 h-12 flex items-center justify-center mx-auto mb-4">
                        <BarChart3 className="w-6 h-6" />
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">Check Inventory</h4>
                      <p className="text-sm text-gray-600">View real-time status</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
              
              <Link href="/reports">
                <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="bg-purple-500 text-white p-3 rounded-lg w-12 h-12 flex items-center justify-center mx-auto mb-4">
                        <BookOpen className="w-6 h-6" />
                      </div>
                      <h4 className="font-medium text-gray-900 mb-2">View Reports</h4>
                      <p className="text-sm text-gray-600">Analytics and insights</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </div>
        </section>

        {/* User Dashboard Preview */}
        {user && (
          <section className="py-16 bg-[hsl(var(--surface-variant))]">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-12">
                <h3 className="text-3xl font-bold text-gray-900 mb-4">
                  Welcome back, {user.fullName.split(' ')[0]}!
                </h3>
                <p className="text-gray-600">Here's your lab activity overview</p>
              </div>
              
              <div className="grid md:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-[hsl(var(--primary))] mb-2">
                        {stats?.pendingReservations || 0}
                      </div>
                      <div className="text-sm text-gray-600">Pending Requests</div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-[hsl(var(--secondary))] mb-2">
                        {stats?.availableEquipment || 0}
                      </div>
                      <div className="text-sm text-gray-600">Available Equipment</div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-[hsl(var(--accent))] mb-2">
                        {user.role === 'student' ? 'Student' : 'Authorized'}
                      </div>
                      <div className="text-sm text-gray-600 capitalize">
                        {user.role.replace('_', ' ')} Access
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>
        )}
      </div>
    </div>
  );
}