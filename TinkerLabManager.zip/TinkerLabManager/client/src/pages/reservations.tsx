import { useEffect, useState } from "react";
import { Navigation } from "@/components/ui/navigation";
import { ReservationForm } from "@/components/ui/reservation-form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import type { ReservationWithDetails } from "@shared/schema";

export default function ReservationsPage() {
  const [location] = useLocation();
  const [selectedEquipmentId, setSelectedEquipmentId] = useState<number | undefined>();

  // Extract equipment ID from URL if present
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const equipmentParam = urlParams.get('equipment');
    if (equipmentParam) {
      setSelectedEquipmentId(parseInt(equipmentParam));
    }
  }, [location]);

  const { data: user } = useQuery<any>({
    queryKey: ['/api/user/profile'],
  });

  const { data: userReservations = [] } = useQuery<ReservationWithDetails[]>({
    queryKey: ['/api/reservations', { userId: user?.id }],
    enabled: !!user?.id,
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>;
      case 'approved':
        return <Badge className="bg-[hsl(var(--secondary))] text-white hover:bg-[hsl(var(--secondary))]">Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-[hsl(var(--error))] text-white hover:bg-[hsl(var(--error))]">Rejected</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500 text-white hover:bg-blue-500">Completed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  return (
    <div className="min-h-screen bg-[hsl(var(--surface))]">
      <Navigation />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Reservation Form */}
            <div className="lg:col-span-2">
              <ReservationForm 
                selectedEquipmentId={selectedEquipmentId}
                onSuccess={() => setSelectedEquipmentId(undefined)}
              />
            </div>

            {/* User's Reservations */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Your Reservations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {userReservations.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <Calendar className="w-8 h-8 mx-auto mb-2" />
                      <p>No reservations yet</p>
                      <p className="text-sm">Submit a request to get started</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {userReservations.slice(0, 5).map((reservation) => (
                        <div key={reservation.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium text-gray-900 text-sm">
                              {reservation.equipment.name}
                            </h4>
                            {getStatusBadge(reservation.status)}
                          </div>
                          
                          <div className="text-xs text-gray-600 space-y-1">
                            <div className="flex items-center">
                              <Calendar className="w-3 h-3 mr-1" />
                              {formatDate(reservation.startDate)}
                            </div>
                            <div className="flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {formatTime(reservation.startDate)} - {formatTime(reservation.endDate)}
                            </div>
                            <div className="text-gray-500">
                              {reservation.duration} hours • {reservation.equipment.location}
                            </div>
                          </div>
                          
                          {reservation.rejectionReason && (
                            <div className="mt-2 p-2 bg-red-50 rounded text-xs text-red-600">
                              <strong>Rejected:</strong> {reservation.rejectionReason}
                            </div>
                          )}
                        </div>
                      ))}
                      
                      {userReservations.length > 5 && (
                        <div className="text-center">
                          <span className="text-sm text-gray-500">
                            +{userReservations.length - 5} more reservations
                          </span>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-[hsl(var(--primary))]">
                        {userReservations.filter(r => r.status === 'pending').length}
                      </div>
                      <div className="text-xs text-gray-600">Pending</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-[hsl(var(--secondary))]">
                        {userReservations.filter(r => r.status === 'approved').length}
                      </div>
                      <div className="text-xs text-gray-600">Approved</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-500">
                        {userReservations.filter(r => r.status === 'completed').length}
                      </div>
                      <div className="text-xs text-gray-600">Completed</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-500">
                        {userReservations.reduce((sum, r) => sum + r.duration, 0)}
                      </div>
                      <div className="text-xs text-gray-600">Total Hours</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
