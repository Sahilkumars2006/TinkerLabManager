import { useState } from "react";
import { Download, BarChart3, Users, Wrench, TrendingUp } from "lucide-react";
import { Navigation } from "@/components/ui/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";

export default function ReportsPage() {
  const [selectedPeriod, setSelectedPeriod] = useState('7');

  const { data: overviewStats } = useQuery<any>({
    queryKey: ['/api/stats/overview'],
  });

  const { data: equipmentStats = [] } = useQuery<any[]>({
    queryKey: ['/api/stats/equipment'],
  });

  const { data: departmentStats = [] } = useQuery<any[]>({
    queryKey: ['/api/stats/departments'],
  });

  const generateReport = (type: string) => {
    console.log(`Generating ${type} report...`);
    // TODO: Implement actual report generation
  };

  const departmentUsageData = [
    { department: 'Mechanical Engineering', usage: 75, color: 'bg-[hsl(var(--primary))]' },
    { department: 'Electrical Engineering', usage: 60, color: 'bg-[hsl(var(--secondary))]' },
    { department: 'Computer Science', usage: 45, color: 'bg-[hsl(var(--accent))]' },
    { department: 'Civil Engineering', usage: 30, color: 'bg-purple-500' },
    { department: 'Chemical Engineering', usage: 20, color: 'bg-pink-500' },
  ];

  return (
    <div className="min-h-screen bg-[hsl(var(--surface))]">
      <Navigation />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Reports & Analytics</h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Comprehensive insights into lab equipment usage, user activity, and operational efficiency.
            </p>
          </div>

          {/* Report Generation Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <CardTitle className="text-lg">Usage Report</CardTitle>
                  <div className="bg-[hsl(var(--primary))] text-white p-2 rounded-lg">
                    <BarChart3 className="w-5 h-5" />
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-6">
                  Detailed equipment utilization statistics and trends over time.
                </p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Most Used:</span>
                    <span className="font-medium">3D Printers</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Peak Hours:</span>
                    <span className="font-medium">2-6 PM</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Avg. Session:</span>
                    <span className="font-medium">2.5 hours</span>
                  </div>
                </div>

                <Button 
                  className="w-full" 
                  onClick={() => generateReport('usage')}
                >
                  Generate Report
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <CardTitle className="text-lg">User Activity</CardTitle>
                  <div className="bg-[hsl(var(--secondary))] text-white p-2 rounded-lg">
                    <Users className="w-5 h-5" />
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-6">
                  Student engagement metrics and department-wise usage analysis.
                </p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Active Users:</span>
                    <span className="font-medium">156 students</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Top Department:</span>
                    <span className="font-medium">Mechanical</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">New This Month:</span>
                    <span className="font-medium">23 users</span>
                  </div>
                </div>

                <Button 
                  className="w-full bg-[hsl(var(--secondary))] hover:bg-[hsl(var(--secondary))]/90" 
                  onClick={() => generateReport('user')}
                >
                  Generate Report
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <CardTitle className="text-lg">Maintenance</CardTitle>
                  <div className="bg-[hsl(var(--accent))] text-white p-2 rounded-lg">
                    <Wrench className="w-5 h-5" />
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-6">
                  Equipment health monitoring and maintenance scheduling insights.
                </p>
                
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Due Soon:</span>
                    <span className="font-medium">3 items</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Avg. Downtime:</span>
                    <span className="font-medium">1.2 days</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Cost This Month:</span>
                    <span className="font-medium">$850</span>
                  </div>
                </div>

                <Button 
                  className="w-full bg-[hsl(var(--accent))] hover:bg-[hsl(var(--accent))]/90" 
                  onClick={() => generateReport('maintenance')}
                >
                  Generate Report
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analytics Dashboard */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl">Analytics Dashboard</CardTitle>
                <div className="flex items-center space-x-4">
                  <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">Last 7 days</SelectItem>
                      <SelectItem value="30">Last 30 days</SelectItem>
                      <SelectItem value="90">Last 3 months</SelectItem>
                      <SelectItem value="365">This year</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button>
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                {/* Equipment Performance Chart */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Equipment Performance</h3>
                  <div className="h-64 bg-[hsl(var(--surface-variant))] rounded-lg flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      <TrendingUp className="w-12 h-12 mx-auto mb-2" />
                      <p>Performance Chart</p>
                      <p className="text-sm">Utilization rates by equipment type</p>
                    </div>
                  </div>
                </div>

                {/* Department Usage Breakdown */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Department Usage</h3>
                  <div className="space-y-4">
                    {departmentUsageData.map((dept) => (
                      <div key={dept.department} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600 flex-1">{dept.department}</span>
                        <div className="flex items-center space-x-2 flex-1">
                          <div className="w-20 bg-gray-200 rounded-full h-2 flex-1">
                            <div 
                              className={`${dept.color} h-2 rounded-full`} 
                              style={{ width: `${dept.usage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-8">{dept.usage}%</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Summary Stats */}
                  <div className="mt-8 p-4 bg-[hsl(var(--surface-variant))] rounded-lg">
                    <h4 className="font-medium text-gray-900 mb-3">This Period Summary</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="text-xl font-bold text-[hsl(var(--primary))]">
                          {overviewStats?.activeReservations || 0}
                        </div>
                        <div className="text-xs text-gray-600">Total Reservations</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-[hsl(var(--secondary))]">
                          {departmentStats.reduce((sum, dept) => sum + (dept.totalHours || 0), 0)}
                        </div>
                        <div className="text-xs text-gray-600">Hours Used</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-[hsl(var(--accent))]">
                          {equipmentStats.reduce((sum, eq) => sum + (eq.total || 0), 0)}
                        </div>
                        <div className="text-xs text-gray-600">Equipment Items</div>
                      </div>
                      <div className="text-center">
                        <div className="text-xl font-bold text-purple-500">
                          {overviewStats?.totalEquipment ? 
                            Math.round((overviewStats.availableEquipment / overviewStats.totalEquipment) * 100) : 0
                          }%
                        </div>
                        <div className="text-xs text-gray-600">Availability</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
