import { useState } from "react";
import { Download, Filter, Clock, CheckCircle, AlertTriangle, Settings, User } from "lucide-react";
import { Navigation } from "@/components/ui/navigation";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ReservationWithDetails } from "@shared/schema";

export default function InventoryPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stats } = useQuery<any>({
    queryKey: ['/api/stats/overview'],
  });

  const { data: activeReservations = [], isLoading } = useQuery<ReservationWithDetails[]>({
    queryKey: ['/api/reservations', { status: 'approved' }],
  });

  const checkInMutation = useMutation({
    mutationFn: async (reservationId: number) => {
      return apiRequest(`/api/reservations/${reservationId}/checkin`, {
        method: 'PATCH',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/overview'] });
      toast({
        title: "Equipment Checked In",
        description: "The equipment has been checked in successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to check in equipment",
        variant: "destructive",
      });
    },
  });

  const checkOutMutation = useMutation({
    mutationFn: async (reservationId: number) => {
      return apiRequest(`/api/reservations/${reservationId}/checkout`, {
        method: 'PATCH',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/overview'] });
      toast({
        title: "Equipment Checked Out",
        description: "The equipment has been returned successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to check out equipment",
        variant: "destructive",
      });
    },
  });

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  const getStatusBadge = (reservation: ReservationWithDetails) => {
    const now = new Date();
    const endDate = new Date(reservation.endDate);
    const isOverdue = now > endDate;
    const isDueSoon = !isOverdue && (endDate.getTime() - now.getTime()) < 2 * 60 * 60 * 1000; // 2 hours

    if (isOverdue) {
      return <Badge className="bg-[hsl(var(--error))] text-white hover:bg-[hsl(var(--error))]">Overdue</Badge>;
    } else if (isDueSoon) {
      return <Badge className="bg-[hsl(var(--accent))] text-white hover:bg-[hsl(var(--accent))]">Due Soon</Badge>;
    } else {
      return <Badge className="bg-[hsl(var(--secondary))] text-white hover:bg-[hsl(var(--secondary))]">On Time</Badge>;
    }
  };

  const currentCheckouts = activeReservations.filter(r => r.checkedInAt && !r.checkedOutAt);

  return (
    <div className="min-h-screen bg-[hsl(var(--surface))]">
      <Navigation />
      <div className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Inventory & Usage Tracking</h1>
              <p className="text-gray-600">Real-time equipment status and usage analytics</p>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
              <Button>
                <Download className="w-4 h-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total Equipment</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {stats?.totalEquipment || 0}
                    </p>
                  </div>
                  <div className="bg-[hsl(var(--primary))] text-white p-3 rounded-lg">
                    <Settings className="w-6 h-6" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <span className="text-[hsl(var(--secondary))] font-medium">Available</span> for use
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Available Now</p>
                    <p className="text-2xl font-bold text-[hsl(var(--secondary))]">
                      {stats?.availableEquipment || 0}
                    </p>
                  </div>
                  <div className="bg-[hsl(var(--secondary))] text-white p-3 rounded-lg">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <span className="text-[hsl(var(--secondary))] font-medium">
                    {stats?.totalEquipment ? Math.round((stats.availableEquipment / stats.totalEquipment) * 100) : 0}%
                  </span> availability rate
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">In Use</p>
                    <p className="text-2xl font-bold text-[hsl(var(--accent))]">
                      {stats?.equipmentInUse || 0}
                    </p>
                  </div>
                  <div className="bg-[hsl(var(--accent))] text-white p-3 rounded-lg">
                    <Clock className="w-6 h-6" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <span className="text-[hsl(var(--accent))] font-medium">
                    {currentCheckouts.filter(r => new Date(r.endDate) < new Date()).length}
                  </span> due back today
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Maintenance</p>
                    <p className="text-2xl font-bold text-[hsl(var(--error))]">
                      {stats?.maintenanceCount || 0}
                    </p>
                  </div>
                  <div className="bg-[hsl(var(--error))] text-white p-3 rounded-lg">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-600">
                  <span className="text-[hsl(var(--error))] font-medium">Est. 2 days</span> to complete
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Real-time Usage Chart Placeholder */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Equipment Usage This Week</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-[hsl(var(--surface-variant))] rounded-lg flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <div className="text-4xl mb-2">📊</div>
                  <p>Usage Analytics Chart</p>
                  <p className="text-sm">Chart visualization would be implemented here</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Check-outs */}
          <Card>
            <CardHeader>
              <CardTitle>Current Check-outs</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center h-32">
                  <Clock className="w-6 h-6 animate-spin" />
                </div>
              ) : currentCheckouts.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <CheckCircle className="w-8 h-8 mx-auto mb-2" />
                  <p>No equipment currently checked out</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-[hsl(var(--surface-variant))]">
                        <TableHead>User</TableHead>
                        <TableHead>Equipment</TableHead>
                        <TableHead>Check-out Time</TableHead>
                        <TableHead>Due Back</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {currentCheckouts.map((reservation) => (
                        <TableRow key={reservation.id} className="hover:bg-gray-50">
                          <TableCell>
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="bg-[hsl(var(--primary))] text-white text-sm font-medium">
                                  {getInitials(reservation.user.fullName)}
                                </AvatarFallback>
                              </Avatar>
                              <div className="ml-3">
                                <div className="text-sm font-medium text-gray-900">
                                  {reservation.user.fullName}
                                </div>
                                <div className="text-sm text-gray-500">
                                  {reservation.user.studentId}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm font-medium text-gray-900">
                              {reservation.equipment.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {reservation.equipment.location}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-gray-900">
                            {reservation.checkedInAt ? (
                              <>
                                {formatDate(reservation.checkedInAt)} {formatTime(reservation.checkedInAt)}
                              </>
                            ) : (
                              'Not checked in'
                            )}
                          </TableCell>
                          <TableCell className="text-sm text-gray-900">
                            {formatDate(reservation.endDate)} {formatTime(reservation.endDate)}
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(reservation)}
                          </TableCell>
                          <TableCell>
                            <div className="flex space-x-2">
                              {!reservation.checkedInAt ? (
                                <Button
                                  size="sm"
                                  onClick={() => checkInMutation.mutate(reservation.id)}
                                  disabled={checkInMutation.isPending}
                                >
                                  Check In
                                </Button>
                              ) : (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => checkOutMutation.mutate(reservation.id)}
                                  disabled={checkOutMutation.isPending}
                                >
                                  Check Out
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
