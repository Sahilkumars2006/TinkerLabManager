# KIT Tinker Lab Management System

## Overview

This project is a comprehensive equipment management system for KIT Engineering College's Tinker Lab. It's built as a full-stack TypeScript application using Express.js for the backend and React for the frontend, designed to streamline equipment reservations, implement multi-level authorization workflows, and provide real-time inventory management.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components (New York style)
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **UI Components**: Comprehensive component library using Radix UI primitives

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: JWT-based authentication with bcrypt for password hashing
- **Database Provider**: Neon serverless PostgreSQL
- **Session Management**: Express sessions with PostgreSQL storage

### Build System
- **Frontend Build**: Vite with React plugin
- **Backend Build**: esbuild for production bundling
- **Development**: tsx for TypeScript execution in development
- **Type Checking**: Shared TypeScript configuration

## Key Components

### Authentication & Authorization
- Role-based access control with multiple user roles:
  - `student`: Basic equipment access
  - `tech_secretary`: Equipment approval authority
  - `club_lead`: Department-level management
  - `faculty`: Academic oversight
  - `phd_scholar`: Research equipment access
  - `admin`: System administration
- JWT token-based authentication
- Middleware for route protection and role verification

### Equipment Management
- Equipment categorization (mechanical, electronics, testing, 3d-printing)
- Status tracking (available, reserved, in_use, maintenance)
- Location and specification management
- Safety requirements tracking
- Image and documentation support

### Reservation System
- Multi-step reservation workflow
- Priority levels (normal, high, urgent)
- Approval workflow with role-based authorization
- Check-in/check-out functionality
- Project description and safety agreement requirements

### Database Schema
- **Users**: Authentication, roles, and profile information
- **Equipment**: Complete equipment catalog with specifications
- **Reservations**: Booking system with approval workflow
- **Usage Logs**: Equipment usage tracking and history
- **Safety Training**: User certification tracking

## Data Flow

1. **User Authentication**: Login credentials → JWT token → Protected routes
2. **Equipment Discovery**: Browse/search equipment → View availability → Initiate reservation
3. **Reservation Workflow**: Submit request → Role-based approval → Equipment allocation
4. **Usage Tracking**: Check-out → Usage logging → Check-in → Completion
5. **Administrative Oversight**: Dashboard monitoring → Reports generation → System management

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **bcryptjs**: Password hashing
- **jsonwebtoken**: JWT token management
- **zod**: Runtime type validation

### Development Tools
- **tsx**: TypeScript execution
- **drizzle-kit**: Database migrations and schema management
- **@replit/vite-plugin-runtime-error-modal**: Development error handling
- **@replit/vite-plugin-cartographer**: Replit integration

## Deployment Strategy

### Production Build
- Frontend assets built with Vite and served statically
- Backend bundled with esbuild for Node.js execution
- PostgreSQL database hosted on Neon serverless platform
- Environment-based configuration management

### Development Environment
- Hot module replacement with Vite
- Automatic TypeScript compilation
- Database schema synchronization with Drizzle
- Integrated error handling and debugging

### Environment Configuration
- Database connection via `DATABASE_URL` environment variable
- JWT secret configuration for security
- Separate development and production configurations

## Changelog

- July 04, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.