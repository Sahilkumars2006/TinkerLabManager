import { pgTable, serial, text, integer, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum('user_role', ['student', 'tech_secretary', 'club_lead', 'faculty', 'phd_scholar', 'admin']);
export const equipmentCategoryEnum = pgEnum('equipment_category', ['mechanical', 'electronics', 'testing', '3d-printing']);
export const equipmentStatusEnum = pgEnum('equipment_status', ['available', 'reserved', 'in_use', 'maintenance']);
export const reservationStatusEnum = pgEnum('reservation_status', ['pending', 'approved', 'rejected', 'completed', 'cancelled']);
export const priorityEnum = pgEnum('priority', ['normal', 'high', 'urgent']);
export const departmentEnum = pgEnum('department', ['mechanical', 'electrical', 'computer', 'civil', 'chemical']);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").unique().notNull(),
  email: text("email").unique().notNull(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  studentId: text("student_id"),
  department: departmentEnum("department"),
  role: userRoleEnum("role").default('student').notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Equipment table
export const equipment = pgTable("equipment", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  model: text("model"),
  description: text("description"),
  category: equipmentCategoryEnum("category").notNull(),
  location: text("location").notNull(),
  status: equipmentStatusEnum("status").default('available').notNull(),
  imageUrl: text("image_url"),
  specifications: text("specifications"),
  safetyRequirements: text("safety_requirements").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Reservations table
export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  equipmentId: integer("equipment_id").references(() => equipment.id).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  duration: integer("duration").notNull(), // in hours
  projectDescription: text("project_description").notNull(),
  priority: priorityEnum("priority").default('normal').notNull(),
  status: reservationStatusEnum("status").default('pending').notNull(),
  approvedBy: integer("approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  rejectionReason: text("rejection_reason"),
  checkedInAt: timestamp("checked_in_at"),
  checkedOutAt: timestamp("checked_out_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Usage logs table
export const usageLogs = pgTable("usage_logs", {
  id: serial("id").primaryKey(),
  reservationId: integer("reservation_id").references(() => reservations.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  equipmentId: integer("equipment_id").references(() => equipment.id).notNull(),
  action: text("action").notNull(), // 'check_in', 'check_out', 'extend', 'cancel'
  notes: text("notes"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Safety training table
export const safetyTraining = pgTable("safety_training", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  trainingType: text("training_type").notNull(),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"),
  certificateUrl: text("certificate_url"),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  reservations: many(reservations),
  approvedReservations: many(reservations),
  usageLogs: many(usageLogs),
  safetyTraining: many(safetyTraining),
}));

export const equipmentRelations = relations(equipment, ({ many }) => ({
  reservations: many(reservations),
  usageLogs: many(usageLogs),
}));

export const reservationsRelations = relations(reservations, ({ one, many }) => ({
  user: one(users, {
    fields: [reservations.userId],
    references: [users.id],
  }),
  equipment: one(equipment, {
    fields: [reservations.equipmentId],
    references: [equipment.id],
  }),
  approver: one(users, {
    fields: [reservations.approvedBy],
    references: [users.id],
  }),
  usageLogs: many(usageLogs),
}));

export const usageLogsRelations = relations(usageLogs, ({ one }) => ({
  reservation: one(reservations, {
    fields: [usageLogs.reservationId],
    references: [reservations.id],
  }),
  user: one(users, {
    fields: [usageLogs.userId],
    references: [users.id],
  }),
  equipment: one(equipment, {
    fields: [usageLogs.equipmentId],
    references: [equipment.id],
  }),
}));

export const safetyTrainingRelations = relations(safetyTraining, ({ one }) => ({
  user: one(users, {
    fields: [safetyTraining.userId],
    references: [users.id],
  }),
}));

// Zod schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertEquipmentSchema = createInsertSchema(equipment).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReservationSchema = createInsertSchema(reservations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  approvedBy: true,
  approvedAt: true,
  checkedInAt: true,
  checkedOutAt: true,
});

export const insertUsageLogSchema = createInsertSchema(usageLogs).omit({
  id: true,
  timestamp: true,
});

export const insertSafetyTrainingSchema = createInsertSchema(safetyTraining).omit({
  id: true,
  completedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Equipment = typeof equipment.$inferSelect;
export type InsertEquipment = z.infer<typeof insertEquipmentSchema>;
export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = z.infer<typeof insertReservationSchema>;
export type UsageLog = typeof usageLogs.$inferSelect;
export type InsertUsageLog = z.infer<typeof insertUsageLogSchema>;
export type SafetyTraining = typeof safetyTraining.$inferSelect;
export type InsertSafetyTraining = z.infer<typeof insertSafetyTrainingSchema>;

// Extended types for API responses
export type ReservationWithDetails = Reservation & {
  user: User;
  equipment: Equipment;
  approver?: User;
};

export type EquipmentWithReservations = Equipment & {
  reservations: Reservation[];
};
